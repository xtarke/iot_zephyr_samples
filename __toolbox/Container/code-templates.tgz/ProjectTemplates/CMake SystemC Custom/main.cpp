#include <systemc>
#include <iostream>

using namespace std;

int sc_main (int argc, char* argv[]) {
	cout << "Hello #{PROJECT_NAME} !" << endl;

	return 0;
}
