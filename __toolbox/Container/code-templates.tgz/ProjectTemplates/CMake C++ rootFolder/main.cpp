#include <iostream>

using namespace std;

int main (int argc, char* argv[]) {
	cout << "Hello #{PROJECT_NAME} !" << endl;

	return 0;
}
